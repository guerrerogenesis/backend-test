-- -------------------------------------------------------------
-- TablePlus 6.2.1(578)
--
-- https://tableplus.com/
--
-- Database: databasetest1
-- Generation Time: 2025-01-23 9:13:25.9820 p.m.
-- -------------------------------------------------------------


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


DROP TABLE IF EXISTS `cache`;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `cache_locks`;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `job_batches`;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `jobs`;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `stock` int NOT NULL,
  `category_id` int NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `categories` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Electronics', '2025-01-22 23:38:01', NULL),
(2, 'Books', '2025-01-22 23:38:01', NULL),
(3, 'Clothing', '2025-01-22 23:38:01', NULL),
(4, 'Toys', '2025-01-22 23:38:01', NULL),
(5, 'Furniture', '2025-01-22 23:38:01', NULL),
(6, 'Food', '2025-01-22 23:38:01', NULL),
(7, 'Beauty', '2025-01-22 23:38:01', NULL),
(8, 'Sports', '2025-01-22 23:38:01', NULL),
(9, 'Tools', '2025-01-22 23:38:01', NULL),
(10, 'Automotive', '2025-01-22 23:38:01', NULL),
(11, 'Producto de prueba', '2025-01-22 23:39:29', '2025-01-22 23:39:29'),
(12, 'Producto de prueba', '2025-01-22 23:44:01', '2025-01-22 23:44:01'),
(13, 'Test category', '2025-01-22 23:45:09', '2025-01-22 23:45:09'),
(14, 'Test category', '2025-01-22 23:45:36', '2025-01-22 23:45:36'),
(15, 'Test category', '2025-01-22 23:51:28', '2025-01-22 23:51:28'),
(16, 'Test category', '2025-01-23 00:16:03', '2025-01-23 00:16:03'),
(17, 'Genesis Guerrero', '2025-01-24 00:26:46', '2025-01-24 00:26:46'),
(18, 'NUEVA CATEGORIA 1', '2025-01-24 00:40:30', '2025-01-24 00:40:30'),
(19, 'Genesis Guerrero', '2025-01-24 01:05:17', '2025-01-24 01:05:17');

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1);

INSERT INTO `products` (`id`, `name`, `stock`, `category_id`, `created_at`, `updated_at`) VALUES
(1, 'Nuevo nombre', 1000, 1, '2025-01-22 23:38:49', '2025-01-24 02:02:33'),
(2, 'Smartphone', 30, 1, '2025-01-22 23:38:49', NULL),
(3, 'Headphones', 500, 1, '2025-01-22 23:38:49', '2025-01-24 02:04:11'),
(4, 'Television', 20, 1, '2025-01-22 23:38:49', NULL),
(5, 'Tablet', 40, 1, '2025-01-22 23:38:49', NULL),
(6, 'E-Reader', 15, 2, '2025-01-22 23:38:49', NULL),
(7, 'Notebook', 60, 2, '2025-01-22 23:38:49', NULL),
(8, 'Comic Book', 100, 2, '2025-01-22 23:38:49', NULL),
(9, 'Novel', 80, 2, '2025-01-22 23:38:49', NULL),
(10, 'Textbook', 25, 2, '2025-01-22 23:38:49', NULL),
(11, 'T-shirt', 200, 3, '2025-01-22 23:38:49', NULL),
(12, 'Jeans', 150, 3, '2025-01-22 23:38:49', NULL),
(13, 'Jacket', 120, 3, '2025-01-22 23:38:49', NULL),
(14, 'Sweater', 90, 3, '2025-01-22 23:38:49', NULL),
(15, 'Cap', 50, 3, '2025-01-22 23:38:49', NULL),
(16, 'Action Figure', 80, 4, '2025-01-22 23:38:49', NULL),
(17, 'Board Game', 30, 4, '2025-01-22 23:38:49', NULL),
(18, 'Doll', 40, 4, '2025-01-22 23:38:49', NULL),
(19, 'Puzzle', 60, 4, '2025-01-22 23:38:49', NULL),
(20, 'Toy Car', 70, 4, '2025-01-22 23:38:49', NULL),
(21, 'Sofa', 10, 5, '2025-01-22 23:38:49', NULL),
(22, 'Dining Table', 5, 5, '2025-01-22 23:38:49', NULL),
(23, 'Chair', 20, 5, '2025-01-22 23:38:49', NULL),
(24, 'Bed Frame', 8, 5, '2025-01-22 23:38:49', NULL),
(25, 'Wardrobe', 3, 5, '2025-01-22 23:38:49', NULL),
(26, 'Cereal', 150, 6, '2025-01-22 23:38:49', NULL),
(27, 'Pasta', 180, 6, '2025-01-22 23:38:49', NULL),
(28, 'Bread', 200, 6, '2025-01-22 23:38:49', NULL),
(29, 'Juice', 250, 6, '2025-01-22 23:38:49', NULL),
(30, 'Snacks', 300, 6, '2025-01-22 23:38:49', NULL),
(31, 'Lipstick', 90, 7, '2025-01-22 23:38:49', NULL),
(32, 'Foundation', 80, 7, '2025-01-22 23:38:49', NULL),
(33, 'Shampoo', 120, 7, '2025-01-22 23:38:49', NULL),
(34, 'Conditioner', 110, 7, '2025-01-22 23:38:49', NULL),
(35, 'Perfume', 70, 7, '2025-01-22 23:38:49', NULL),
(36, 'Soccer Ball', 50, 8, '2025-01-22 23:38:49', NULL),
(37, 'Basketball', 30, 8, '2025-01-22 23:38:49', NULL),
(38, 'Tennis Racket', 20, 8, '2025-01-22 23:38:49', NULL),
(39, 'Yoga Mat', 40, 8, '2025-01-22 23:38:49', NULL),
(40, 'Dumbbells', 25, 8, '2025-01-22 23:38:49', NULL),
(41, 'Hammer', 60, 9, '2025-01-22 23:38:49', NULL),
(42, 'Screwdriver', 80, 9, '2025-01-22 23:38:49', NULL),
(43, 'Wrench', 40, 9, '2025-01-22 23:38:49', NULL),
(44, 'Drill', 20, 9, '2025-01-22 23:38:49', NULL),
(45, 'Saw', 10, 9, '2025-01-22 23:38:49', NULL),
(46, 'Car Oil', 50, 10, '2025-01-22 23:38:49', NULL),
(47, 'Tire', 25, 10, '2025-01-22 23:38:49', NULL),
(48, 'Battery', 30, 10, '2025-01-22 23:38:49', NULL),
(49, 'Brake Pads', 20, 10, '2025-01-22 23:38:49', NULL),
(50, 'Engine Cleaner', 15, 10, '2025-01-22 23:38:49', NULL),
(51, 'Random Product 1', 20, 4, '2025-01-22 23:38:49', NULL),
(52, 'Random Product 2', 15, 6, '2025-01-22 23:38:49', NULL),
(53, 'Random Product 3', 18, 7, '2025-01-22 23:38:49', NULL),
(54, 'Random Product 4', 25, 7, '2025-01-22 23:38:49', NULL),
(55, 'Random Product 5', 10, 2, '2025-01-22 23:38:49', NULL),
(56, 'Random Product 6', 35, 9, '2025-01-22 23:38:49', NULL),
(57, 'Random Product 7', 40, 7, '2025-01-22 23:38:49', NULL),
(58, 'Random Product 8', 45, 1, '2025-01-22 23:38:49', NULL),
(59, 'Random Product 9', 50, 1, '2025-01-22 23:38:49', NULL),
(60, 'Random Product 10', 60, 4, '2025-01-22 23:38:49', NULL),
(61, 'Random Product 11', 55, 6, '2025-01-22 23:38:49', NULL),
(62, 'Random Product 12', 48, 7, '2025-01-22 23:38:49', NULL),
(63, 'Random Product 13', 30, 8, '2025-01-22 23:38:49', NULL),
(64, 'Random Product 14', 27, 9, '2025-01-22 23:38:49', NULL),
(65, 'Random Product 15', 33, 8, '2025-01-22 23:38:49', NULL),
(66, 'Random Product 16', 22, 2, '2025-01-22 23:38:49', NULL),
(67, 'Random Product 17', 19, 7, '2025-01-22 23:38:49', NULL),
(68, 'Random Product 18', 28, 6, '2025-01-22 23:38:49', NULL),
(73, 'hola', 0, 2, '2025-01-23 21:18:01', '2025-01-23 21:18:01'),
(74, 'hola', 0, 2, '2025-01-23 21:19:41', '2025-01-23 21:19:41'),
(75, 'hola', 5, 5, '2025-01-23 21:20:40', '2025-01-23 21:20:40'),
(77, 'Génesis Daniela', 7, 3, '2025-01-23 21:38:59', '2025-01-23 21:38:59'),
(78, 'Rodríguez', 6, 3, '2025-01-23 21:49:19', '2025-01-23 21:49:19'),
(79, 'Génesis Daniela', 5, 5, '2025-01-23 21:58:11', '2025-01-23 21:58:11'),
(80, 'hhhh', 7, 5, '2025-01-23 22:00:09', '2025-01-23 22:00:09'),
(81, 'hhhh', 7, 5, '2025-01-23 22:00:45', '2025-01-23 22:00:45'),
(82, 'Génesis Daniela', 5, 4, '2025-01-23 22:02:16', '2025-01-23 22:02:16'),
(83, 'Génesis Daniela', 7, 4, '2025-01-23 22:03:09', '2025-01-23 22:03:09'),
(84, 'Nuevo productop', 5, 7, '2025-01-23 22:06:03', '2025-01-23 22:06:03');

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('5vHg2gBm5CRUGmPmLBI2iWZNoE0szRozEyT2MqtT', NULL, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYnprWjI5ZVNSMDZ1ZTJMVHNEcGo0eVJwemxtamJiaEg1bEtUcGlMMSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1737578303),
('iIHsyzWskAUFNLty5iiuuwdrxYAR3XqnjXzArT0r', NULL, '127.0.0.1', 'insomnia/2023.4.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUm5USEQ1MjRmb1doZ2xKczBNSGJnZ1JIcTk4VGVBV0ZxSWY0WVRFRCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzA6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9wcm9kdWN0cyI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1737580444),
('nRUu8FCblxCOq1c0y1cFrIo8lpiqEcqj1krJ8JvY', NULL, '127.0.0.1', 'insomnia/2023.4.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiRXJSUURWTHcyWWlrZVpTTmJld3FZTzUzQXF1YnRMa05neDRjOXQxTSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1737590548),
('ueKb13V1vG7J3qyTdPf21wWoqdNsKk2AxpvOhEl1', NULL, '127.0.0.1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiSkpDblZrT284bHMxZks0cVVCMFVHUlNjZ1FPNE9NMFFPU1Z2OFQyeiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1737650384);



/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;